"""
StoryFactGraph — V5 Evidence-First Structured Fact Generation
=============================================================

Builds a graph of GroundedFact objects ONLY from:
  - recap.json episode transcripts
  - story_memory.json
  - comic title / episode range metadata
  - Stage 11 timeline (optional)

Invariant: Every GroundedFact with confidence > 0 MUST have len(evidence) >= 1.
           This is enforced by evidence_required_invariant_check().

TEXT CANNOT CONTAIN A FACT THAT IS NOT IN THE STRUCTURED FACT GRAPH.
"""

from __future__ import annotations

import json
import os
import re
import hashlib
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# =============================================================================
# FACT TYPES — 21 supported categories
# =============================================================================

VALID_FACT_TYPES = {
    "disaster_event",
    "location_event",
    "combat_event",
    "survival_event",
    "betrayal_event",
    "resource_event",
    "shelter_event",
    "military_event",
    "character_action",
    "character_state",
    "group_state",
    "environment_state",
    "time_fact",
    "numeric_fact",
    "relationship_event",
    "death_event",
    "escape_event",
    "arrival_event",
    "departure_event",
    "containment_event",
    "infection_event",
}


# =============================================================================
# GROUNDED FACT DATACLASS
# =============================================================================

@dataclass
class GroundedFact:
    """
    A single structured fact extracted from evidence (recap.json transcripts,
    story_memory). Every field is derived from actual source data.

    Invariant: if confidence > 0, len(evidence) >= 1.
    """
    fact_id: str                        # e.g. "combat_event_ep042_001"
    type: str                           # one of VALID_FACT_TYPES
    subject: str                        # "Tae", "zombie horde", "military"
    predicate: str                      # "fights", "overruns", "deploys"
    object: str                         # "infected squad", "city block"
    scope: str                          # "episode" | "arc" | "series"
    episode_start: int
    episode_end: int
    confidence: float                   # 0.0–1.0
    canonical_text: str                 # human-readable summary
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    # evidence items: {"episode": int, "segment_index": int, "snippet": str, "source": str}

    def __post_init__(self) -> None:
        if self.type not in VALID_FACT_TYPES:
            raise ValueError(f"Invalid fact type: '{self.type}'. Must be one of {sorted(VALID_FACT_TYPES)}")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fact_id": self.fact_id,
            "type": self.type,
            "subject": self.subject,
            "predicate": self.predicate,
            "object": self.object,
            "scope": self.scope,
            "episode_start": self.episode_start,
            "episode_end": self.episode_end,
            "confidence": self.confidence,
            "canonical_text": self.canonical_text,
            "evidence_count": len(self.evidence),
            "evidence": self.evidence[:3],  # export first 3 snippets
        }


# =============================================================================
# EXTRACTION PATTERNS — word-boundary safe
# =============================================================================

# Each entry: (fact_type, subject, predicate, object_template, patterns_list, confidence)
_EXTRACTION_RULES: List[Tuple[str, str, str, str, List[str], float]] = [
    # Infection / outbreak events
    ("infection_event", "infected", "spreads", "population",
     ["infect", "outbreak", "virus", "patient zero", "bitten", "spreading", "contagion", "contaminate"],
     0.85),
    # Zombie / undead encounters
    ("combat_event", "protagonist", "fights", "infected horde",
     ["zombie", "undead", "ghoul", "horde", "swarm", "infected crowd", "mob of infected"],
     0.80),
    # Military / martial law
    ("military_event", "military", "deploys", "response force",
     ["military", "soldier", "troop", "conscript", "martial law", "national guard", "army unit", "squad"],
     0.75),
    # Containment / quarantine
    ("containment_event", "authority", "enforces", "quarantine zone",
     ["quarantine", "containment", "lockdown", "sealed", "barricade", "blockade", "isolation zone"],
     0.80),
    # Shelter secured
    ("shelter_event", "protagonist", "secures", "shelter",
     ["shelter", "safehouse", "hideout", "safe zone", "fortified", "barricaded", "bunker", "refuge"],
     0.75),
    # Resource acquisition
    ("resource_event", "protagonist", "acquires", "supplies",
     ["food", "water", "medicine", "ammo", "supply", "stockpile", "provision", "ration", "fuel"],
     0.70),
    # Betrayal
    ("betrayal_event", "ally", "betrays", "protagonist",
     ["betray", "backstab", "abandoned", "left for dead", "shut the door", "locked out", "coward"],
     0.85),
    # Death events
    ("death_event", "character", "dies", "in conflict",
     ["died", "killed", "dead", "murder", "sacrifice", "perish", "fatal", "loss of life", "casualty"],
     0.75),
    # Escape / flee
    ("escape_event", "protagonist", "escapes", "danger zone",
     ["escape", "fled", "run away", "evacuate", "retreat", "break out", "get out"],
     0.70),
    # Arrival at location
    ("arrival_event", "protagonist", "arrives", "new location",
     ["arrive", "reach", "get to", "found", "discovered location", "enter the"],
     0.65),
    # Departure from location
    ("departure_event", "protagonist", "departs", "previous location",
     ["leave", "depart", "abandon the", "move out", "evacuated from", "flee from"],
     0.65),
    # Environmental hazard
    ("environment_state", "environment", "is", "hazardous",
     ["ruin", "collapse", "debris", "fire", "flood", "destroyed city", "devastat", "rubble"],
     0.70),
    # Group survival state
    ("group_state", "group", "are", "survivors",
     ["group", "team", "squad", "crew", "allies", "party", "band of survivors"],
     0.60),
    # Disaster-scale event
    ("disaster_event", "disaster", "destroys", "city/region",
     ["apocalypse", "outbreak overrun", "city fell", "total collapse", "end of the world", "civilization fell"],
     0.85),
    # Location event (named location)
    ("location_event", "protagonist", "at", "named location",
     ["hospital", "school", "subway station", "rooftop", "apartment", "warehouse", "mall", "bridge", "highway"],
     0.65),
    # Character action (generic significant action)
    ("character_action", "protagonist", "acts", "under pressure",
     ["risked", "sacrificed", "saved", "rescued", "protected", "defended", "fought off", "held the line"],
     0.75),
    # Character state
    ("character_state", "protagonist", "is", "in danger",
     ["injured", "trapped", "surrounded", "exhausted", "starving", "dehydrated", "outnumbered", "cornered"],
     0.70),
    # Relationship event
    ("relationship_event", "characters", "form", "relationship",
     ["trust", "allied", "team up", "friendship", "bond", "partner", "joined forces"],
     0.65),
]


def _word_boundary_match(text_lower: str, keywords: List[str]) -> Optional[str]:
    """
    Match keywords with word boundaries where possible.
    Returns the matching snippet substring, or None if no match.
    Prevents false positives like 'training' matching 'rain'.
    """
    for kw in keywords:
        if " " in kw:
            # Multi-word phrase: exact substring match
            if kw in text_lower:
                start = text_lower.find(kw)
                return text_lower[max(0, start - 10):start + len(kw) + 40]
        else:
            # Single word: require word boundary
            m = re.search(r'\b' + re.escape(kw) + r'\b', text_lower)
            if m:
                start = m.start()
                return text_lower[max(0, start - 10):start + len(kw) + 40]
    return None


# =============================================================================
# STORY FACT GRAPH
# =============================================================================

class StoryFactGraph:
    """
    Evidence-first structured fact graph built ONLY from real source data.

    Usage:
        graph = StoryFactGraph(
            comic_title="Zombie Revelation",
            archetype="zombie_apocalypse",
            download_dir="downloads/좀비묵시록_8208_1_143_en_946016ec",
            from_ep=1, to_ep=143,
            story_memory={...},
        ).build()

        facts = graph.get_facts_by_type("combat_event")
        violations = graph.evidence_required_invariant_check()
    """

    def __init__(
        self,
        comic_title: str,
        archetype: str,
        download_dir: str,
        from_ep: int,
        to_ep: int,
        story_memory: Optional[Dict[str, Any]] = None,
        stage11_timeline: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        self.comic_title = comic_title
        self.archetype = archetype
        self.download_dir = download_dir
        self.from_ep = from_ep
        self.to_ep = to_ep
        self.story_memory = story_memory or {}
        self.stage11_timeline = stage11_timeline or []

        self._facts: List[GroundedFact] = []
        self._built = False
        self._episodes_scanned: int = 0
        self._episodes_found: int = 0

    # -------------------------------------------------------------------------
    # PUBLIC API
    # -------------------------------------------------------------------------

    def build(self) -> "StoryFactGraph":
        """Extract all facts from source data. Must be called before querying."""
        if self._built:
            return self
        self._facts = []
        self._extract_from_episodes()
        self._extract_from_story_memory()
        self._built = True
        return self

    def get_facts_by_type(self, fact_type: str) -> List[GroundedFact]:
        """Return all facts of a given type, sorted by confidence descending."""
        return sorted(
            [f for f in self._facts if f.type == fact_type],
            key=lambda f: f.confidence,
            reverse=True,
        )

    def get_facts_for_episode_range(
        self, ep_start: int, ep_end: int
    ) -> List[GroundedFact]:
        """Return facts whose episode range overlaps with [ep_start, ep_end]."""
        return [
            f for f in self._facts
            if f.episode_end >= ep_start and f.episode_start <= ep_end
        ]

    def get_distinct_fact_types(self) -> List[str]:
        """Return the list of distinct fact types present in the graph."""
        return sorted({f.type for f in self._facts})

    def select_facts_for_template(
        self, required_types: List[str]
    ) -> Optional[Dict[str, "GroundedFact"]]:
        """
        Select one best fact per required type for template filling.
        Returns None if any required type has no facts.
        """
        result: Dict[str, GroundedFact] = {}
        for req_type in required_types:
            candidates = self.get_facts_by_type(req_type)
            if not candidates:
                return None
            result[req_type] = candidates[0]
        return result

    def evidence_required_invariant_check(self) -> List[str]:
        """
        Verify invariant: every fact with confidence > 0 must have evidence.
        Returns list of violation strings (empty = all good).
        """
        violations: List[str] = []
        for f in self._facts:
            if f.confidence > 0 and len(f.evidence) == 0:
                violations.append(
                    f"INVARIANT VIOLATED: fact '{f.fact_id}' (type={f.type}) "
                    f"has confidence={f.confidence} but evidence=[] — "
                    f"requires_evidence=True rule broken."
                )
        return violations

    def to_json(self) -> Dict[str, Any]:
        """Serialize the full fact graph to a JSON-serializable dict."""
        return {
            "comic_title": self.comic_title,
            "archetype": self.archetype,
            "from_ep": self.from_ep,
            "to_ep": self.to_ep,
            "episodes_scanned": self._episodes_scanned,
            "episodes_found": self._episodes_found,
            "total_facts": len(self._facts),
            "distinct_fact_types": self.get_distinct_fact_types(),
            "invariant_violations": self.evidence_required_invariant_check(),
            "facts": [f.to_dict() for f in self._facts],
        }

    def __len__(self) -> int:
        return len(self._facts)

    # -------------------------------------------------------------------------
    # PRIVATE: EXTRACTION FROM EPISODES
    # -------------------------------------------------------------------------

    def _make_fact_id(self, fact_type: str, ep: int, counter: int) -> str:
        return f"{fact_type}_ep{ep:03d}_{counter:03d}"

    def _extract_from_episodes(self) -> None:
        """Scan all recap.json files and extract GroundedFacts."""
        if not self.download_dir or not os.path.isdir(self.download_dir):
            return

        fact_counter: Dict[str, int] = {}

        for ep in range(self.from_ep, self.to_ep + 1):
            self._episodes_scanned += 1
            recap_path = os.path.join(
                self.download_dir, f"episode_{ep}", "recap.json"
            )
            if not os.path.isfile(recap_path):
                continue
            self._episodes_found += 1

            try:
                with open(recap_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue

            if not isinstance(data, list):
                continue

            segments = [
                item.get("speech", "")
                for item in data
                if isinstance(item, dict) and item.get("speech")
            ]
            if not segments:
                continue

            for rule in _EXTRACTION_RULES:
                fact_type, subject, predicate, obj, keywords, conf = rule

                # Find first matching segment (word boundary)
                for seg_idx, seg in enumerate(segments):
                    seg_lower = seg.lower()
                    matched_snippet = _word_boundary_match(seg_lower, keywords)
                    if matched_snippet:
                        ftype_counter = fact_counter.get(fact_type, 0) + 1
                        fact_counter[fact_type] = ftype_counter

                        fact_id = self._make_fact_id(fact_type, ep, ftype_counter)
                        canonical = (
                            f"[Ep {ep}] {subject.title()} {predicate} {obj} "
                            f"(from: \"{seg[:80].strip()}...\")"
                        )
                        fact = GroundedFact(
                            fact_id=fact_id,
                            type=fact_type,
                            subject=subject,
                            predicate=predicate,
                            object=obj,
                            scope="episode",
                            episode_start=ep,
                            episode_end=ep,
                            confidence=conf,
                            canonical_text=canonical,
                            evidence=[{
                                "episode": ep,
                                "segment_index": seg_idx,
                                "snippet": seg[:200],
                                "source": "recap",
                                "source_path": recap_path,
                            }],
                        )
                        self._facts.append(fact)
                        break  # one fact per rule per episode is enough

    # -------------------------------------------------------------------------
    # PRIVATE: EXTRACTION FROM STORY MEMORY
    # -------------------------------------------------------------------------

    def _extract_from_story_memory(self) -> None:
        """Extract structured facts from story_memory fields."""
        if not self.story_memory:
            return

        mem = self.story_memory
        mem_str = str(mem).lower()
        fact_counter: Dict[str, int] = {}

        def _mem_fact(
            fact_type: str, subject: str, predicate: str, obj: str,
            conf: float, snippet: str,
        ) -> GroundedFact:
            c = fact_counter.get(fact_type, 0) + 1
            fact_counter[fact_type] = c
            fact_id = f"{fact_type}_mem_{c:03d}"
            return GroundedFact(
                fact_id=fact_id,
                type=fact_type,
                subject=subject,
                predicate=predicate,
                object=obj,
                scope="series",
                episode_start=self.from_ep,
                episode_end=self.to_ep,
                confidence=conf,
                canonical_text=f"[story_memory] {subject} {predicate} {obj}",
                evidence=[{
                    "episode": 0,
                    "segment_index": -1,
                    "snippet": snippet[:200],
                    "source": "story_memory",
                    "source_path": "",
                }],
            )

        # Protagonist name
        protagonist = mem.get("protagonist_name", "")
        if protagonist and len(protagonist) > 1:
            self._facts.append(_mem_fact(
                "character_state", protagonist, "is", "the protagonist",
                0.95, f"protagonist_name: {protagonist}",
            ))

        # Betrayal
        if any(k in mem_str for k in ["betray", "backstab", "left for dead", "abandoned"]):
            self._facts.append(_mem_fact(
                "betrayal_event", "ally", "betrays", "protagonist",
                0.90, f"story_memory betrayal: {mem_str[:100]}",
            ))

        # Shelter/bunker
        if "bunker" in mem_str or "shelter" in mem_str or "safehouse" in mem_str:
            self._facts.append(_mem_fact(
                "shelter_event", "protagonist", "uses", "shelter/bunker",
                0.85, f"story_memory shelter: {mem_str[:100]}",
            ))

        # Day number (time_fact)
        if "day" in mem:
            day_val = mem["day"]
            if isinstance(day_val, (int, float)) and day_val > 0:
                self._facts.append(_mem_fact(
                    "time_fact", "story", "spans", f"Day {int(day_val)}",
                    0.90, f"story_memory day: {day_val}",
                ))

        # Survival threat (infection/disaster from story_memory)
        if any(k in mem_str for k in ["zombie", "infected", "outbreak", "virus", "undead"]):
            self._facts.append(_mem_fact(
                "infection_event", "virus", "spreads", "population",
                0.90, f"story_memory infection: {mem_str[:100]}",
            ))

        # Military presence
        if any(k in mem_str for k in ["military", "soldier", "army", "martial law"]):
            self._facts.append(_mem_fact(
                "military_event", "military", "responds", "to outbreak",
                0.80, f"story_memory military: {mem_str[:100]}",
            ))

        # Group/party
        if "party_size" in mem and isinstance(mem["party_size"], (int, float)):
            ps = int(mem["party_size"])
            if ps > 1:
                self._facts.append(_mem_fact(
                    "group_state", "group", "has", f"{ps} survivors",
                    0.85, f"story_memory party_size: {ps}",
                ))

    # -------------------------------------------------------------------------
    # CONVENIENCE: Summary statistics for provenance tracking
    # -------------------------------------------------------------------------

    def provenance_summary(self) -> Dict[str, Any]:
        """Returns a provenance summary for inclusion in output metadata."""
        type_counts: Dict[str, int] = {}
        total_evidence = 0
        for f in self._facts:
            type_counts[f.type] = type_counts.get(f.type, 0) + 1
            total_evidence += len(f.evidence)
        return {
            "total_facts": len(self._facts),
            "distinct_types": len(self.get_distinct_fact_types()),
            "fact_types_present": self.get_distinct_fact_types(),
            "total_evidence_units": total_evidence,
            "episodes_scanned": self._episodes_scanned,
            "episodes_found": self._episodes_found,
            "invariant_violations": len(self.evidence_required_invariant_check()),
            "type_counts": type_counts,
        }
